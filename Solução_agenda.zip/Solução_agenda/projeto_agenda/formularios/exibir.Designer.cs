﻿namespace projeto_agenda.formularios
{
    partial class exibir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataSet_agenda = new projeto_agenda.dados.DataSet_agenda();
            this.dataSetagendaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dSPESSOABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetagendaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dS_PESSOATableAdapter = new projeto_agenda.dados.DataSet_agendaTableAdapters.DS_PESSOATableAdapter();
            this.dataSetagendaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eNDERECODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDADEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMAILDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dATANASCIMENTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CBbuscar = new System.Windows.Forms.ComboBox();
            this.CMBB1 = new System.Windows.Forms.ComboBox();
            this.btnfiltro = new System.Windows.Forms.Button();
            this.tbvalor = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet_agenda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetagendaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dSPESSOABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetagendaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetagendaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataSet_agenda
            // 
            this.dataSet_agenda.DataSetName = "DataSet_agenda";
            this.dataSet_agenda.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataSetagendaBindingSource
            // 
            this.dataSetagendaBindingSource.DataSource = this.dataSet_agenda;
            this.dataSetagendaBindingSource.Position = 0;
            // 
            // dSPESSOABindingSource
            // 
            this.dSPESSOABindingSource.DataMember = "DS_PESSOA";
            this.dSPESSOABindingSource.DataSource = this.dataSetagendaBindingSource1;
            // 
            // dataSetagendaBindingSource1
            // 
            this.dataSetagendaBindingSource1.DataSource = this.dataSet_agenda;
            this.dataSetagendaBindingSource1.Position = 0;
            // 
            // dS_PESSOATableAdapter
            // 
            this.dS_PESSOATableAdapter.ClearBeforeFill = true;
            // 
            // dataSetagendaBindingSource2
            // 
            this.dataSetagendaBindingSource2.DataSource = this.dataSet_agenda;
            this.dataSetagendaBindingSource2.Position = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.nOMEDataGridViewTextBoxColumn,
            this.eNDERECODataGridViewTextBoxColumn,
            this.cIDADEDataGridViewTextBoxColumn,
            this.eMAILDataGridViewTextBoxColumn,
            this.dATANASCIMENTODataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.dSPESSOABindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(26, 89);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(743, 214);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Width = 150;
            // 
            // nOMEDataGridViewTextBoxColumn
            // 
            this.nOMEDataGridViewTextBoxColumn.DataPropertyName = "NOME";
            this.nOMEDataGridViewTextBoxColumn.HeaderText = "NOME";
            this.nOMEDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.nOMEDataGridViewTextBoxColumn.Name = "nOMEDataGridViewTextBoxColumn";
            this.nOMEDataGridViewTextBoxColumn.Width = 150;
            // 
            // eNDERECODataGridViewTextBoxColumn
            // 
            this.eNDERECODataGridViewTextBoxColumn.DataPropertyName = "ENDERECO";
            this.eNDERECODataGridViewTextBoxColumn.HeaderText = "ENDERECO";
            this.eNDERECODataGridViewTextBoxColumn.MinimumWidth = 8;
            this.eNDERECODataGridViewTextBoxColumn.Name = "eNDERECODataGridViewTextBoxColumn";
            this.eNDERECODataGridViewTextBoxColumn.Width = 150;
            // 
            // cIDADEDataGridViewTextBoxColumn
            // 
            this.cIDADEDataGridViewTextBoxColumn.DataPropertyName = "CIDADE";
            this.cIDADEDataGridViewTextBoxColumn.HeaderText = "CIDADE";
            this.cIDADEDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cIDADEDataGridViewTextBoxColumn.Name = "cIDADEDataGridViewTextBoxColumn";
            this.cIDADEDataGridViewTextBoxColumn.Width = 150;
            // 
            // eMAILDataGridViewTextBoxColumn
            // 
            this.eMAILDataGridViewTextBoxColumn.DataPropertyName = "EMAIL";
            this.eMAILDataGridViewTextBoxColumn.HeaderText = "EMAIL";
            this.eMAILDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.eMAILDataGridViewTextBoxColumn.Name = "eMAILDataGridViewTextBoxColumn";
            this.eMAILDataGridViewTextBoxColumn.Width = 150;
            // 
            // dATANASCIMENTODataGridViewTextBoxColumn
            // 
            this.dATANASCIMENTODataGridViewTextBoxColumn.DataPropertyName = "DATA_NASCIMENTO";
            this.dATANASCIMENTODataGridViewTextBoxColumn.HeaderText = "DATA_NASCIMENTO";
            this.dATANASCIMENTODataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dATANASCIMENTODataGridViewTextBoxColumn.Name = "dATANASCIMENTODataGridViewTextBoxColumn";
            this.dATANASCIMENTODataGridViewTextBoxColumn.Width = 150;
            // 
            // CBbuscar
            // 
            this.CBbuscar.FormattingEnabled = true;
            this.CBbuscar.Items.AddRange(new object[] {
            "todos",
            "igual",
            "que começa com",
            "que termina com",
            "que contém",
            "que esteja entre"});
            this.CBbuscar.Location = new System.Drawing.Point(267, 34);
            this.CBbuscar.Name = "CBbuscar";
            this.CBbuscar.Size = new System.Drawing.Size(121, 28);
            this.CBbuscar.TabIndex = 2;
            // 
            // CMBB1
            // 
            this.CMBB1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CMBB1.FormattingEnabled = true;
            this.CMBB1.Items.AddRange(new object[] {
            "ID",
            "NOME",
            "ENDERECO",
            "CIDADE",
            "EMAIL",
            "DATA_NASCIMENTO"});
            this.CMBB1.Location = new System.Drawing.Point(26, 34);
            this.CMBB1.Name = "CMBB1";
            this.CMBB1.Size = new System.Drawing.Size(121, 28);
            this.CMBB1.TabIndex = 3;
            // 
            // btnfiltro
            // 
            this.btnfiltro.Location = new System.Drawing.Point(694, 36);
            this.btnfiltro.Name = "btnfiltro";
            this.btnfiltro.Size = new System.Drawing.Size(75, 23);
            this.btnfiltro.TabIndex = 4;
            this.btnfiltro.Text = "filtrar";
            this.btnfiltro.UseVisualStyleBackColor = true;
            this.btnfiltro.Click += new System.EventHandler(this.btnfiltro_Click);
            // 
            // tbvalor
            // 
            this.tbvalor.Location = new System.Drawing.Point(523, 36);
            this.tbvalor.Name = "tbvalor";
            this.tbvalor.Size = new System.Drawing.Size(100, 26);
            this.tbvalor.TabIndex = 5;
            // 
            // exibir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbvalor);
            this.Controls.Add(this.btnfiltro);
            this.Controls.Add(this.CMBB1);
            this.Controls.Add(this.CBbuscar);
            this.Controls.Add(this.dataGridView1);
            this.Name = "exibir";
            this.Text = "exibir";
            this.Load += new System.EventHandler(this.exibir_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet_agenda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetagendaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dSPESSOABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetagendaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetagendaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private dados.DataSet_agenda dataSet_agenda;
        private System.Windows.Forms.BindingSource dataSetagendaBindingSource;
        private System.Windows.Forms.BindingSource dataSetagendaBindingSource1;
        private System.Windows.Forms.BindingSource dSPESSOABindingSource;
        private dados.DataSet_agendaTableAdapters.DS_PESSOATableAdapter dS_PESSOATableAdapter;
        private System.Windows.Forms.BindingSource dataSetagendaBindingSource2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eNDERECODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDADEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMAILDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dATANASCIMENTODataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox CBbuscar;
        private System.Windows.Forms.ComboBox CMBB1;
        private System.Windows.Forms.Button btnfiltro;
        private System.Windows.Forms.TextBox tbvalor;
    }
}